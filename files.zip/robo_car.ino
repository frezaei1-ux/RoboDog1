// Robo-Dog RC car firmware: ESP32 + 1 DC drive motor (L298N / H-bridge) + 1 steering servo
// Requires ESP32 Arduino core 3.x (uses ledcAttach / ledcWrite(pin, duty)); no extra libraries.
// The ESP32 creates its own Wi-Fi network: join "RoboDog" on the phone, then the app
// talks to http://192.168.4.1 (the default address in Profile settings).
//
// If you already have a sketch with /scan, merge the handlers into it
// instead of running two WebServers.

#include <WiFi.h>
#include <WebServer.h>

const char* AP_SSID = "RoboDog";
const char* AP_PASS = "robodog123";       // at least 8 characters

// ---- Pins (change to match your wiring) ----
const int ENA = 14, IN1 = 27, IN2 = 26;   // DC motor via H-bridge (ENA = speed, IN1/IN2 = direction)
const int SERVO_PIN = 13;                 // steering servo signal wire
const int LIGHTS = 4;                     // headlight LED (through a resistor)
const int BUZZER = 15;                    // active buzzer (optional)

// ---- Steering calibration ----
const int SERVO_CENTER = 90;              // adjust if the wheels aren't straight at 90
const int SERVO_RANGE  = 40;              // max degrees each side; protects the linkage
const int PULSE_MIN_US = 500, PULSE_MAX_US = 2400;   // 0..180 degrees

const unsigned long FAILSAFE_MS = 600;    // motor off + wheels straight if no command for this long

WebServer server(80);
unsigned long lastCmd = 0;

void cors() {
  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.sendHeader("Cache-Control", "no-store");
}

// DC motor: speed -255..255. Positive = forward, negative = reverse, 0 = off.
void setMotor(int speed) {
  speed = constrain(speed, -255, 255);
  digitalWrite(IN1, speed > 0);
  digitalWrite(IN2, speed < 0);
  ledcWrite(ENA, abs(speed));
}

// Servo: 50 Hz, 16-bit duty. angle 0..180.
void setServo(int angle) {
  angle = constrain(angle, SERVO_CENTER - SERVO_RANGE, SERVO_CENTER + SERVO_RANGE);
  uint32_t us = map(angle, 0, 180, PULSE_MIN_US, PULSE_MAX_US);
  ledcWrite(SERVO_PIN, (uint32_t)((uint64_t)us * 65535 / 20000));
}

void handleCar() {                        // /car?speed=-255..255&angle=0..180
  setMotor(server.arg("speed").toInt());
  setServo(server.hasArg("angle") ? server.arg("angle").toInt() : SERVO_CENTER);
  lastCmd = millis();
  cors(); server.send(200, "text/plain", "ok");
}

void handleMove() {                       // /move?dir=forward|back|left|right|stop (older Drive page)
  String d = server.arg("dir");
  setMotor(d == "forward" || d == "left" || d == "right" ? 180 : d == "back" ? -180 : 0);
  setServo(d == "left" ? SERVO_CENTER - SERVO_RANGE : d == "right" ? SERVO_CENTER + SERVO_RANGE : SERVO_CENTER);
  lastCmd = millis();
  cors(); server.send(200, "text/plain", "ok");
}

void handleLights() {                     // /lights?on=1
  digitalWrite(LIGHTS, server.arg("on") == "1");
  cors(); server.send(200, "text/plain", "ok");
}

void handleHorn() {                       // /horn?ms=300
  int ms = constrain(server.arg("ms").toInt(), 50, 1000);
  digitalWrite(BUZZER, HIGH); delay(ms); digitalWrite(BUZZER, LOW);
  cors(); server.send(200, "text/plain", "ok");
}

void setup() {
  int outs[] = {IN1, IN2, LIGHTS, BUZZER};
  for (int p : outs) { pinMode(p, OUTPUT); digitalWrite(p, LOW); }
  ledcAttach(ENA, 1000, 8);               // motor PWM: pin, Hz, bits
  ledcAttach(SERVO_PIN, 50, 16);          // servo PWM
  setMotor(0);
  setServo(SERVO_CENTER);

  WiFi.softAP(AP_SSID, AP_PASS);

  server.on("/car", handleCar);
  server.on("/move", handleMove);
  server.on("/lights", handleLights);
  server.on("/horn", handleHorn);
  server.begin();
}

void loop() {
  server.handleClient();
  if (millis() - lastCmd > FAILSAFE_MS) { setMotor(0); setServo(SERVO_CENTER); }
}
